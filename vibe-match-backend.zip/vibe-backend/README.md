# Vibe Match — Backend

Backend for the *Anonymous Match / Starlit Commons* front end. Node 20+, Express, Socket.IO, PostgreSQL (Prisma), Redis.

Every endpoint below maps to a surface in the Figma file.

## Run it

```bash
cp .env.example .env          # fill SPOTIFY_* and JWT_SECRET
npm install
npx prisma migrate dev --name init
npm run seed                  # optional: synthetic listeners so the radar isn't empty
npm run dev                   # http://localhost:8080
```

Spotify dashboard → add redirect URI `http://localhost:8080/api/auth/spotify/callback`.
Scopes used: `user-top-read`, `user-read-recently-played`, `user-read-private`, `user-read-email`, playback read/modify (for Listen in Sync).

Deploy: `render.yaml` provisions web + Postgres + Redis. `Dockerfile` runs migrations on boot.

## Auth model

Spotify OAuth authorization-code flow. The callback issues a 30-day JWT, set both as an `httpOnly` cookie (`vm_session`) and appended to the redirect as `#token=...` so an SPA can grab it. Send it as `Authorization: Bearer <jwt>` or rely on the cookie.

A user's real Spotify identity (name, avatar, email) is stored but **never** leaves the API until both people in a room set reveal to `MUTUAL`.

## REST surface

### Landing page — "THE ROOM RIGHT NOW"
| Method | Path | Notes |
|---|---|---|
| `GET` | `/api/stats/live` | Public. Online count, gentlemen/ladies split, waiting pools, active conversations, today's matches/messages/songs/reveals. Cached 3s. |
| `GET` | `/api/health` | DB + Redis check. |

### Phase 1 — Spotify auth & vibe quiz
| Method | Path | Notes |
|---|---|---|
| `GET` | `/api/auth/spotify?returnTo=/onboarding` | Redirect target for the "Dynamic Soulmate Spotify Button". |
| `GET` | `/api/auth/spotify/callback` | Exchanges code, creates the user, assigns an anonymous handle (`midnight-tulip`), kicks off taste ingestion. |
| `POST` | `/api/auth/gender` | `{ gender: "MALE" \| "FEMALE", timezone? }`. Required — pairing is guaranteed boy-girl. |
| `GET` | `/api/quiz` | Public. The 5 scenario questions, including the "2 AM stars" teaser. |
| `POST` | `/api/quiz/answers` | `{ answers: [{ questionId, optionId }] }` → recomputes the vibe vector, flips state to `IDLE` when complete. |
| `GET` | `/api/me` | Handle, gender, state, vibe metrics, active room id, queue position. |
| `POST` | `/api/me/refresh-taste` | Re-pulls Spotify top tracks/artists and recomputes. |
| `GET` | `/api/me/top-tracks` | For the vinyl / orbital art. |

### State A — the Romantic Waiting Sphere
| Method | Path | Notes |
|---|---|---|
| `POST` | `/api/match/queue` | Step onto the radar. |
| `DELETE` | `/api/match/queue` | Step off. |
| `GET` | `/api/match/status` | Queue position, both-side pool sizes, wait time, live telemetry. |

### 1:1 anonymous chat
| Method | Path | Notes |
|---|---|---|
| `GET` | `/api/chat/rooms/:roomId` | Affinity %, partner handle + vibe breakdown, reveal state. |
| `GET` | `/api/chat/rooms/:roomId/messages?before=&limit=` | Paged history, newest last. |
| `POST` | `/api/chat/rooms/:roomId/messages` | REST fallback; prefer the socket. |
| `GET` | `/api/chat/search/tracks?q=` | Spotify search proxied — the client never holds a token. |
| `POST` | `/api/chat/rooms/:roomId/songs` | `{ spotifyId, note? }` → shared song card + sideboard entry. |
| `GET` | `/api/chat/rooms/:roomId/songs` | "Shared Romantic Songs" panel. |
| `POST` | `/api/chat/rooms/:roomId/reveal` | `{ decision: "REQUEST" \| "ACCEPT" \| "DECLINE" }`. Identity unlocks only on mutual. |
| `POST` | `/api/chat/rooms/:roomId/leave` | Ends the room, both users back to `IDLE`. |

### The Starlit Commons
| Method | Path | Notes |
|---|---|---|
| `GET` | `/api/lounge/messages` | Public read so the lounge previews before sign-in. |
| `GET` | `/api/lounge/pulse` | Collective frequency bars + "Now Playing in Commons". |
| `POST` | `/api/lounge/messages` | Max 500 chars. |
| `POST` | `/api/lounge/messages/:id/reactions` | `{ emoji }` — toggles. |
| `POST` | `/api/lounge/now-playing` | `{ spotifyId }` — syncs one track across every listener. |

## Socket.IO contract

Connect with `io(API_URL, { auth: { token } })`.

**Server → client**
- `stats:live` — broadcast every 5s, same shape as `/api/stats/live`
- `match:found` — `{ roomId, affinity, partner: { handle, gender }, breakdown }`
- `chat:message` — `{ id, roomId, kind: TEXT|SONG|ICEBREAKER, body, meta, senderId, createdAt }`
- `chat:typing` — `{ handle, typing }`
- `music:sync` — `{ spotifyId, positionMs, playing, at, by }`
- `partner:presence` — `{ online, handle }`
- `reveal:update` — `{ roomId, revealA, revealB, mutual }`
- `room:ended` — `{ roomId, endedBy }`
- `lounge:message`, `lounge:reaction`, `lounge:nowplaying`

**Client → server** (all take an ack callback)
- `match:join`, `match:leave`, `match:ping`
- `chat:join` `{ roomId }`, `chat:send` `{ roomId, body }`, `chat:typing` `{ roomId, typing }`, `chat:leave`
- `music:sync` `{ roomId, spotifyId, positionMs, playing }`
- `lounge:join`, `lounge:send` `{ body }`, `lounge:react` `{ messageId, emoji }`, `lounge:leave`

## How matching works

1. Spotify top tracks → audio features → a 6-axis taste vector (valence, energy, acousticness, danceability, instrumentalness, tempo).
2. Quiz answers add three axes: romantic depth, playfulness, vulnerability.
3. Those nine axes collapse into the three bars the drawer renders: **Nocturnal Tenderness**, **Acoustic Melancholy**, **Emotional Openness**.
4. Waiting users sit in two Redis sorted sets (`queue:waiting:MALE` / `:FEMALE`), scored by join time.
5. Every `MATCH_TICK_MS` the matchmaker walks the queue oldest-first and picks the highest-affinity opposite-gender candidate.
6. **Affinity** = weighted axis closeness (70%) + shared artist/track overlap (30%), rendered as e.g. `98.4%`.
7. The acceptance threshold starts at `MATCH_MIN_AFFINITY` and decays `MATCH_DECAY_PER_MIN` per minute of waiting, floored at `MATCH_FLOOR_AFFINITY` — so nobody waits on the radar forever.
8. Room creation takes Redis `NX` locks on both users and re-checks state inside a transaction, so two ticks (or two instances) can't double-match anyone.
9. An AI-style icebreaker card is seeded into the room, built from the strongest shared artist.

Tune the knobs in `.env`.

## Scaling notes

- The matchmaker runs in-process by default. On more than one instance, run `npm run matchmaker` as a single worker and add a Redis adapter (`@socket.io/redis-adapter`) so `io.to(...)` fans out across instances.
- Presence is a Redis sorted set swept on a 45s stale window; sockets heartbeat every 20s.
- Lounge history lives in Postgres (paged), not Redis, so it survives restarts.

## Gaps left deliberately

- No moderation layer on lounge/chat text. Add one before opening it up.
- Spotify's `/audio-features` is deprecated for apps created after Nov 2024. If your client ID is new, swap `services/vibe.js` `ingestSpotifyTaste` to derive axes from artist genres + a self-report slider instead; the rest of the pipeline is unchanged.
- `music:sync` relays position only. Actual playback needs Spotify Premium on both sides via the Web Playback SDK.
