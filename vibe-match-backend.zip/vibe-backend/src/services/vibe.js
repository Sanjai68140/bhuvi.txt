import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { prisma } from '../lib/prisma.js';
import { spotify } from './spotify.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
export const QUIZ = JSON.parse(readFileSync(join(__dirname, '../data/quiz.json'), 'utf8'));

const clamp01 = (n) => Math.min(1, Math.max(0, n));
const avg = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0.5);
const pct = (n) => Math.round(clamp01(n) * 100);

/**
 * Pull the user's top tracks/artists, derive the raw taste vector from Spotify
 * audio features, and persist both the vector and the top items used for overlap.
 */
export async function ingestSpotifyTaste(userId) {
  const [tracks, artists] = await Promise.all([
    spotify.topTracks(userId, 50).catch(() => ({ items: [] })),
    spotify.topArtists(userId, 30).catch(() => ({ items: [] })),
  ]);

  const trackItems = tracks.items || [];
  const ids = trackItems.map((t) => t.id).filter(Boolean).slice(0, 100);

  let features = [];
  for (let i = 0; i < ids.length; i += 100) {
    const res = await spotify.audioFeatures(userId, ids.slice(i, i + 100)).catch(() => ({ audio_features: [] }));
    features = features.concat((res.audio_features || []).filter(Boolean));
  }

  const raw = {
    valence: avg(features.map((f) => f.valence)),
    energy: avg(features.map((f) => f.energy)),
    acousticness: avg(features.map((f) => f.acousticness)),
    danceability: avg(features.map((f) => f.danceability)),
    instrumentalness: avg(features.map((f) => f.instrumentalness)),
    tempoNorm: clamp01((avg(features.map((f) => f.tempo || 110)) - 60) / 120),
  };

  const tasteChips = dedupe([
    ...(artists.items || []).flatMap((a) => a.genres || []),
  ]).slice(0, 8);

  await prisma.$transaction([
    prisma.topItem.deleteMany({ where: { userId } }),
    prisma.topItem.createMany({
      data: [
        ...trackItems.slice(0, 50).map((t, i) => ({
          userId,
          kind: 'track',
          spotifyId: t.id,
          name: t.name,
          artistName: t.artists?.[0]?.name ?? null,
          imageUrl: t.album?.images?.[0]?.url ?? null,
          previewUrl: t.preview_url ?? null,
          rank: i,
        })),
        ...(artists.items || []).slice(0, 30).map((a, i) => ({
          userId,
          kind: 'artist',
          spotifyId: a.id,
          name: a.name,
          imageUrl: a.images?.[0]?.url ?? null,
          rank: i,
        })),
      ],
      skipDuplicates: true,
    }),
    prisma.vibeProfile.upsert({
      where: { userId },
      create: { userId, ...raw, ...displayMetrics(raw), tasteChips },
      update: { ...raw, ...displayMetrics(raw), tasteChips, computedAt: new Date() },
    }),
  ]);

  return recomputeProfile(userId);
}

/** The three bars rendered in the "Love Vibe Breakdown" drawer. */
function displayMetrics(raw, quiz = {}) {
  const nocturnalTenderness = clamp01(
    0.35 * (1 - raw.energy) + 0.3 * raw.acousticness + 0.2 * (1 - raw.valence) + 0.15 * (quiz.romanticDepth ?? 0.5),
  );
  const acousticMelancholy = clamp01(
    0.45 * raw.acousticness + 0.35 * (1 - raw.valence) + 0.1 * raw.instrumentalness + 0.1 * (1 - raw.tempoNorm),
  );
  const emotionalOpenness = clamp01(
    0.45 * (quiz.vulnerability ?? 0.5) + 0.25 * (quiz.romanticDepth ?? 0.5) + 0.2 * raw.valence + 0.1 * raw.danceability,
  );
  return {
    nocturnalTenderness: pct(nocturnalTenderness),
    acousticMelancholy: pct(acousticMelancholy),
    emotionalOpenness: pct(emotionalOpenness),
  };
}

/** Fold saved quiz answers into the stored profile. */
export async function recomputeProfile(userId) {
  const [profile, answers] = await Promise.all([
    prisma.vibeProfile.findUnique({ where: { userId } }),
    prisma.quizAnswer.findMany({ where: { userId } }),
  ]);
  if (!profile) return null;

  const buckets = {};
  for (const a of answers) {
    const q = QUIZ.questions.find((x) => x.id === a.questionId);
    const opt = q?.options.find((o) => o.id === a.optionId);
    if (!opt) continue;
    for (const [k, v] of Object.entries(opt.weights)) {
      (buckets[k] ||= []).push(v);
    }
  }
  const quiz = {
    romanticDepth: buckets.romanticDepth ? avg(buckets.romanticDepth) : profile.romanticDepth,
    playfulness: buckets.playfulness ? avg(buckets.playfulness) : profile.playfulness,
    vulnerability: buckets.vulnerability ? avg(buckets.vulnerability) : profile.vulnerability,
  };

  const raw = {
    valence: profile.valence,
    energy: profile.energy,
    acousticness: profile.acousticness,
    danceability: profile.danceability,
    instrumentalness: profile.instrumentalness,
    tempoNorm: profile.tempoNorm,
  };

  return prisma.vibeProfile.update({
    where: { userId },
    data: { ...quiz, ...displayMetrics(raw, quiz), computedAt: new Date() },
  });
}

function dedupe(arr) {
  return [...new Set(arr.map((s) => String(s).trim()).filter(Boolean))];
}

export function publicVibe(profile) {
  if (!profile) return null;
  return {
    metrics: [
      { key: 'nocturnal_tenderness', label: 'Nocturnal Tenderness', value: profile.nocturnalTenderness },
      { key: 'acoustic_melancholy', label: 'Acoustic Melancholy', value: profile.acousticMelancholy },
      { key: 'emotional_openness', label: 'Emotional Openness', value: profile.emotionalOpenness },
    ],
    chips: profile.tasteChips,
  };
}
