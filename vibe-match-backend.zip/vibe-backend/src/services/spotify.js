import { httpJson } from '../lib/http.js';
import { env } from '../config/env.js';
import { prisma } from '../lib/prisma.js';

const AUTH = 'https://accounts.spotify.com';
const API = 'https://api.spotify.com/v1';

export const SCOPES = [
  'user-read-email',
  'user-read-private',
  'user-top-read',
  'user-read-recently-played',
  'user-read-playback-state',
  'user-modify-playback-state',
  'user-read-currently-playing',
].join(' ');

export function authorizeUrl(state) {
  const q = new URLSearchParams({
    client_id: env.SPOTIFY_CLIENT_ID,
    response_type: 'code',
    redirect_uri: env.SPOTIFY_REDIRECT_URI,
    scope: SCOPES,
    state,
    show_dialog: 'false',
  });
  return `${AUTH}/authorize?${q.toString()}`;
}

function basicAuth() {
  return 'Basic ' + Buffer.from(`${env.SPOTIFY_CLIENT_ID}:${env.SPOTIFY_CLIENT_SECRET}`).toString('base64');
}

export async function exchangeCode(code) {
  return httpJson(`${AUTH}/api/token`, {
    method: 'POST',
    headers: { Authorization: basicAuth(), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      redirect_uri: env.SPOTIFY_REDIRECT_URI,
    }),
  });
}

export async function refreshAccessToken(refreshToken) {
  return httpJson(`${AUTH}/api/token`, {
    method: 'POST',
    headers: { Authorization: basicAuth(), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: refreshToken }),
  });
}

/** Returns a valid access token for a user, refreshing and persisting it when stale. */
export async function tokenFor(userId) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { accessToken: true, refreshToken: true, tokenExpires: true },
  });
  if (!user?.accessToken) throw Object.assign(new Error('Spotify not linked'), { status: 409 });

  const fresh = user.tokenExpires && user.tokenExpires.getTime() - Date.now() > 60_000;
  if (fresh) return user.accessToken;
  if (!user.refreshToken) throw Object.assign(new Error('Spotify re-auth required'), { status: 401 });

  const t = await refreshAccessToken(user.refreshToken);
  await prisma.user.update({
    where: { id: userId },
    data: {
      accessToken: t.access_token,
      refreshToken: t.refresh_token || user.refreshToken,
      tokenExpires: new Date(Date.now() + t.expires_in * 1000),
    },
  });
  return t.access_token;
}

async function api(userId, path, init = {}) {
  const token = await tokenFor(userId);
  return httpJson(`${API}${path}`, {
    ...init,
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
}

export const spotify = {
  me: (token) => httpJson(`${API}/me`, { headers: { Authorization: `Bearer ${token}` } }),
  topTracks: (userId, limit = 50, range = 'medium_term') =>
    api(userId, `/me/top/tracks?limit=${limit}&time_range=${range}`),
  topArtists: (userId, limit = 30, range = 'medium_term') =>
    api(userId, `/me/top/artists?limit=${limit}&time_range=${range}`),
  audioFeatures: (userId, ids) => api(userId, `/audio-features?ids=${ids.join(',')}`),
  track: (userId, id) => api(userId, `/tracks/${id}`),
  searchTracks: (userId, q, limit = 10) =>
    api(userId, `/search?type=track&limit=${limit}&q=${encodeURIComponent(q)}`),
  recentlyPlayed: (userId, limit = 20) => api(userId, `/me/player/recently-played?limit=${limit}`),
  currentlyPlaying: (userId) => api(userId, '/me/player/currently-playing'),
  play: (userId, uris, positionMs = 0) =>
    api(userId, '/me/player/play', { method: 'PUT', body: JSON.stringify({ uris, position_ms: positionMs }) }),
};
