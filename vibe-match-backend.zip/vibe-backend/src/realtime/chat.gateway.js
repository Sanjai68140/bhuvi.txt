import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { bumpDailyStat } from '../services/telemetry.js';

const sendSchema = z.object({ roomId: z.string(), body: z.string().trim().min(1).max(2000) });

async function assertMember(userId, roomId) {
  const room = await prisma.room.findUnique({
    where: { id: roomId },
    select: { id: true, state: true, userAId: true, userBId: true },
  });
  if (!room) throw new Error('room_not_found');
  if (room.userAId !== userId && room.userBId !== userId) throw new Error('forbidden');
  return room;
}

export function registerChat(io, socket) {
  const user = socket.data.user;

  socket.on('chat:join', async ({ roomId }, ack) => {
    try {
      await assertMember(user.id, roomId);
      socket.join(`room:${roomId}`);
      ack?.({ ok: true });
      socket.to(`room:${roomId}`).emit('partner:presence', { online: true, handle: user.handle });
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('chat:send', async (payload, ack) => {
    try {
      const { roomId, body } = sendSchema.parse(payload);
      const room = await assertMember(user.id, roomId);
      if (room.state !== 'ACTIVE') return ack?.({ error: 'room_ended' });

      const msg = await prisma.message.create({
        data: { roomId, senderId: user.id, kind: 'TEXT', body },
      });
      await prisma.room.update({ where: { id: roomId }, data: { messageCount: { increment: 1 } } });
      bumpDailyStat('messagesSent', 1).catch(() => {});

      io.to(`room:${roomId}`).emit('chat:message', {
        id: msg.id, roomId, kind: 'TEXT', body, senderId: user.id, createdAt: msg.createdAt,
      });
      ack?.({ id: msg.id, createdAt: msg.createdAt });
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('chat:typing', async ({ roomId, typing }) => {
    socket.to(`room:${roomId}`).emit('chat:typing', { handle: user.handle, typing: Boolean(typing) });
  });

  /** "Listen in Sync" — mirrors playback position to the other person. */
  socket.on('music:sync', async ({ roomId, spotifyId, positionMs, playing }) => {
    try {
      await assertMember(user.id, roomId);
      socket.to(`room:${roomId}`).emit('music:sync', {
        spotifyId,
        positionMs: Number(positionMs) || 0,
        playing: Boolean(playing),
        at: Date.now(),
        by: user.handle,
      });
    } catch { /* ignore */ }
  });

  socket.on('chat:leave', ({ roomId }) => {
    socket.leave(`room:${roomId}`);
    socket.to(`room:${roomId}`).emit('partner:presence', { online: false, handle: user.handle });
  });
}
