import { prisma } from '../lib/prisma.js';
import { redis, KEYS } from '../lib/redis.js';

const STALE_MS = 45_000; // a heartbeat older than this is considered offline

export async function heartbeat(userId, gender) {
  const now = Date.now();
  const tx = redis.multi().zadd(KEYS.online, now, userId);
  if (gender) tx.zadd(KEYS.onlineGender(gender), now, userId);
  await tx.exec();
}

export async function goOffline(userId, gender) {
  const tx = redis.multi().zrem(KEYS.online, userId);
  if (gender) tx.zrem(KEYS.onlineGender(gender), userId);
  await tx.exec();
}

async function sweep() {
  const cutoff = Date.now() - STALE_MS;
  await redis
    .multi()
    .zremrangebyscore(KEYS.online, 0, cutoff)
    .zremrangebyscore(KEYS.onlineGender('MALE'), 0, cutoff)
    .zremrangebyscore(KEYS.onlineGender('FEMALE'), 0, cutoff)
    .exec();
}

/** Powers the landing page "THE ROOM RIGHT NOW" bento grid and the waiting-sphere telemetry. */
export async function liveStats() {
  await sweep();
  const today = startOfDay();
  const [online, male, female, waitingM, waitingF, day] = await Promise.all([
    redis.zcard(KEYS.online),
    redis.zcard(KEYS.onlineGender('MALE')),
    redis.zcard(KEYS.onlineGender('FEMALE')),
    redis.zcard(KEYS.waitingPool('MALE')),
    redis.zcard(KEYS.waitingPool('FEMALE')),
    prisma.dailyStat.findUnique({ where: { day: today } }),
  ]);
  const activeRooms = await prisma.room.count({ where: { state: 'ACTIVE' } });

  return {
    hopelessRomanticsOnline: online,
    gentleGentlemen: male,
    lovelyLadies: female,
    waiting: { male: waitingM, female: waitingF, total: waitingM + waitingF },
    activeConversations: activeRooms,
    today: {
      matchesMade: day?.matchesMade ?? 0,
      messagesSent: day?.messagesSent ?? 0,
      songsShared: day?.songsShared ?? 0,
      mutualReveals: day?.revealsMutual ?? 0,
    },
    generatedAt: new Date().toISOString(),
  };
}

export function startOfDay(d = new Date()) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}

export async function bumpDailyStat(field, by = 1) {
  const day = startOfDay();
  await prisma.dailyStat.upsert({
    where: { day },
    create: { day, [field]: by },
    update: { [field]: { increment: by } },
  });
}

/** Broadcasts live counters to everyone on the landing page / waiting radar. */
export function startTelemetryBroadcast(io, intervalMs = 5000) {
  const handle = setInterval(async () => {
    try {
      io.emit('stats:live', await liveStats());
    } catch { /* non-fatal */ }
  }, intervalMs);
  return () => clearInterval(handle);
}
