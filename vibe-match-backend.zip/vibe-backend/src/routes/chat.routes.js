import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { requireAuth, requireReady } from '../middleware/auth.js';
import { ah } from '../middleware/error.js';
import { writeLimiter } from '../middleware/rateLimit.js';
import { bumpDailyStat } from '../services/telemetry.js';
import { spotify } from '../services/spotify.js';
import { publicVibe } from '../services/vibe.js';

export const chatRouter = Router();
chatRouter.use(requireAuth, requireReady);

/** Loads a room the caller belongs to, or 403s. */
async function roomFor(userId, roomId) {
  const room = await prisma.room.findUnique({
    where: { id: roomId },
    include: {
      userA: { select: { id: true, handle: true, gender: true, displayName: true, avatarUrl: true, vibe: true } },
      userB: { select: { id: true, handle: true, gender: true, displayName: true, avatarUrl: true, vibe: true } },
    },
  });
  if (!room) throw Object.assign(new Error('room_not_found'), { status: 404 });
  if (room.userAId !== userId && room.userBId !== userId) {
    throw Object.assign(new Error('forbidden'), { status: 403 });
  }
  const isA = room.userAId === userId;
  return { room, me: isA ? room.userA : room.userB, partner: isA ? room.userB : room.userA, isA };
}

export function serialiseRoom({ room, partner, isA }) {
  const mutual = room.revealA === 'MUTUAL' && room.revealB === 'MUTUAL';
  return {
    id: room.id,
    affinity: room.affinity,
    state: room.state,
    messageCount: room.messageCount,
    createdAt: room.createdAt,
    partner: {
      handle: partner.handle,
      gender: partner.gender,
      vibe: publicVibe(partner.vibe),
      // Identity only crosses the wall after both sides consent.
      revealed: mutual ? { displayName: partner.displayName, avatarUrl: partner.avatarUrl } : null,
    },
    reveal: {
      mine: isA ? room.revealA : room.revealB,
      theirs: isA ? room.revealB : room.revealA,
      mutual,
    },
    breakdown: room.breakdown,
  };
}

chatRouter.get('/rooms/:roomId', ah(async (req, res) => {
  const ctx = await roomFor(req.user.id, req.params.roomId);
  res.json(serialiseRoom(ctx));
}));

chatRouter.get('/rooms/:roomId/messages', ah(async (req, res) => {
  await roomFor(req.user.id, req.params.roomId);
  const { before, limit = '50' } = req.query;
  const rows = await prisma.message.findMany({
    where: {
      roomId: req.params.roomId,
      ...(before ? { createdAt: { lt: new Date(String(before)) } } : {}),
    },
    orderBy: { createdAt: 'desc' },
    take: Math.min(Number(limit) || 50, 100),
  });
  res.json({
    messages: rows.reverse().map((m) => ({
      id: m.id,
      kind: m.kind,
      body: m.body,
      meta: m.meta,
      mine: m.senderId === req.user.id,
      createdAt: m.createdAt,
    })),
  });
}));

/** REST fallback for sending — the live path is the socket event `chat:send`. */
const sendSchema = z.object({ body: z.string().trim().min(1).max(2000) });

chatRouter.post('/rooms/:roomId/messages', writeLimiter, ah(async (req, res) => {
  const { room } = await roomFor(req.user.id, req.params.roomId);
  if (room.state !== 'ACTIVE') return res.status(409).json({ error: 'room_ended' });
  const { body } = sendSchema.parse(req.body);

  const [msg] = await prisma.$transaction([
    prisma.message.create({ data: { roomId: room.id, senderId: req.user.id, kind: 'TEXT', body } }),
    prisma.room.update({ where: { id: room.id }, data: { messageCount: { increment: 1 } } }),
  ]);
  await bumpDailyStat('messagesSent', 1);

  req.app.get('io')?.to(`room:${room.id}`).emit('chat:message', {
    id: msg.id, roomId: room.id, kind: 'TEXT', body, senderId: req.user.id, createdAt: msg.createdAt,
  });
  res.status(201).json({ id: msg.id, createdAt: msg.createdAt });
}));

/** Shared Romantic Songs panel + the in-chat player card. */
const songSchema = z.object({
  spotifyId: z.string().min(5),
  note: z.string().max(280).optional(),
});

chatRouter.post('/rooms/:roomId/songs', writeLimiter, ah(async (req, res) => {
  const { room } = await roomFor(req.user.id, req.params.roomId);
  if (room.state !== 'ACTIVE') return res.status(409).json({ error: 'room_ended' });
  const { spotifyId, note } = songSchema.parse(req.body);

  const track = await spotify.track(req.user.id, spotifyId);
  const song = await prisma.sharedSong.upsert({
    where: { roomId_spotifyId: { roomId: room.id, spotifyId } },
    create: {
      roomId: room.id,
      sharedById: req.user.id,
      spotifyId,
      title: track.name,
      artist: track.artists?.map((a) => a.name).join(', ') ?? '',
      albumArtUrl: track.album?.images?.[0]?.url ?? null,
      previewUrl: track.preview_url ?? null,
      durationMs: track.duration_ms ?? null,
      note: note ?? null,
    },
    update: { note: note ?? undefined },
  });

  const msg = await prisma.message.create({
    data: {
      roomId: room.id,
      senderId: req.user.id,
      kind: 'SONG',
      body: note || `${song.title} — ${song.artist}`,
      meta: song,
    },
  });
  await prisma.room.update({ where: { id: room.id }, data: { messageCount: { increment: 1 } } });
  await bumpDailyStat('songsShared', 1);

  req.app.get('io')?.to(`room:${room.id}`).emit('chat:message', {
    id: msg.id, roomId: room.id, kind: 'SONG', body: msg.body, meta: song,
    senderId: req.user.id, createdAt: msg.createdAt,
  });
  res.status(201).json(song);
}));

chatRouter.get('/rooms/:roomId/songs', ah(async (req, res) => {
  await roomFor(req.user.id, req.params.roomId);
  const songs = await prisma.sharedSong.findMany({
    where: { roomId: req.params.roomId },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ songs });
}));

/** Search for a track to share (proxied so the client never holds a Spotify token). */
chatRouter.get('/search/tracks', ah(async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (q.length < 2) return res.json({ items: [] });
  const data = await spotify.searchTracks(req.user.id, q, 10);
  res.json({
    items: (data.tracks?.items || []).map((t) => ({
      spotifyId: t.id,
      title: t.name,
      artist: t.artists?.map((a) => a.name).join(', '),
      albumArtUrl: t.album?.images?.[2]?.url ?? t.album?.images?.[0]?.url ?? null,
      previewUrl: t.preview_url,
      durationMs: t.duration_ms,
    })),
  });
}));

/** Mutual Reveal Invitation banner. Identity unlocks only when both sides opt in. */
chatRouter.post('/rooms/:roomId/reveal', writeLimiter, ah(async (req, res) => {
  const { room, isA } = await roomFor(req.user.id, req.params.roomId);
  const decision = z.enum(['REQUEST', 'ACCEPT', 'DECLINE']).parse(req.body?.decision);

  const mineField = isA ? 'revealA' : 'revealB';
  const theirsField = isA ? 'revealB' : 'revealA';
  const theirs = room[theirsField];

  let data;
  if (decision === 'DECLINE') {
    data = { [mineField]: 'DECLINED' };
  } else if (theirs === 'REQUESTED' || theirs === 'MUTUAL') {
    data = { revealA: 'MUTUAL', revealB: 'MUTUAL', revealedAt: new Date() };
  } else {
    data = { [mineField]: 'REQUESTED' };
  }

  const updated = await prisma.room.update({ where: { id: room.id }, data });
  const mutual = updated.revealA === 'MUTUAL' && updated.revealB === 'MUTUAL';
  if (mutual && !room.revealedAt) await bumpDailyStat('revealsMutual', 1);

  req.app.get('io')?.to(`room:${room.id}`).emit('reveal:update', {
    roomId: room.id,
    revealA: updated.revealA,
    revealB: updated.revealB,
    mutual,
  });

  const ctx = await roomFor(req.user.id, room.id);
  res.json(serialiseRoom(ctx));
}));

chatRouter.post('/rooms/:roomId/leave', ah(async (req, res) => {
  const { room } = await roomFor(req.user.id, req.params.roomId);
  if (room.state === 'ENDED') return res.json({ ok: true });

  await prisma.$transaction([
    prisma.room.update({ where: { id: room.id }, data: { state: 'ENDED', endedAt: new Date() } }),
    prisma.user.updateMany({ where: { id: { in: [room.userAId, room.userBId] } }, data: { state: 'IDLE' } }),
  ]);
  req.app.get('io')?.to(`room:${room.id}`).emit('room:ended', { roomId: room.id, endedBy: req.user.handle });
  res.json({ ok: true });
}));
