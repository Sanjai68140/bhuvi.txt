import { prisma } from '../lib/prisma.js';

// Anonymous aliases in the tone of the design: "midnight-tulip", "midnight-wanderer".
const PREFIX = [
  'midnight', 'velvet', 'starlit', 'moonlit', 'amber', 'dusky', 'rosewood', 'silver',
  'twilight', 'cobalt', 'hazel', 'crimson', 'paper', 'winter', 'quiet', 'golden',
];
const SUFFIX = [
  'tulip', 'wanderer', 'echo', 'sonnet', 'ember', 'orbit', 'lantern', 'harbour',
  'marigold', 'reverie', 'cassette', 'daydream', 'compass', 'petal', 'nocturne', 'aurora',
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

export async function generateHandle() {
  for (let i = 0; i < 12; i++) {
    const base = `${pick(PREFIX)}-${pick(SUFFIX)}`;
    const candidate = i < 6 ? base : `${base}-${Math.floor(Math.random() * 90 + 10)}`;
    const taken = await prisma.user.findUnique({ where: { handle: candidate }, select: { id: true } });
    if (!taken) return candidate;
  }
  return `${pick(PREFIX)}-${pick(SUFFIX)}-${Date.now().toString(36).slice(-4)}`;
}
