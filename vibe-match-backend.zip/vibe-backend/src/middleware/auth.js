import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { prisma } from '../lib/prisma.js';

export function signToken(userId) {
  return jwt.sign({ sub: userId }, env.JWT_SECRET, { expiresIn: env.JWT_TTL });
}

export function verifyToken(token) {
  return jwt.verify(token, env.JWT_SECRET);
}

function bearer(req) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) return h.slice(7);
  return req.cookies?.vm_session || null;
}

export async function requireAuth(req, res, next) {
  try {
    const token = bearer(req);
    if (!token) return res.status(401).json({ error: 'unauthenticated' });
    const { sub } = verifyToken(token);
    const user = await prisma.user.findUnique({
      where: { id: sub },
      select: { id: true, handle: true, gender: true, state: true, spotifyId: true },
    });
    if (!user) return res.status(401).json({ error: 'unauthenticated' });
    req.user = user;
    prisma.user.update({ where: { id: user.id }, data: { lastSeenAt: new Date() } }).catch(() => {});
    next();
  } catch {
    res.status(401).json({ error: 'unauthenticated' });
  }
}

/** Blocks routes that need a finished onboarding (gender + quiz + vibe profile). */
export function requireReady(req, res, next) {
  if (req.user.state === 'ONBOARDING') {
    return res.status(409).json({ error: 'onboarding_incomplete' });
  }
  next();
}
