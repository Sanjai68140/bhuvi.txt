import http from 'node:http';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import pinoHttp from 'pino-http';

import { env } from './config/env.js';
import { logger } from './lib/logger.js';
import { prisma } from './lib/prisma.js';
import { redis } from './lib/redis.js';

import { generalLimiter } from './middleware/rateLimit.js';
import { notFound, errorHandler } from './middleware/error.js';

import { authRouter } from './routes/auth.routes.js';
import { meRouter } from './routes/me.routes.js';
import { quizRouter } from './routes/quiz.routes.js';
import { matchRouter } from './routes/match.routes.js';
import { chatRouter } from './routes/chat.routes.js';
import { loungeRouter } from './routes/lounge.routes.js';
import { statsRouter } from './routes/stats.routes.js';

import { createRealtime } from './realtime/index.js';
import { startMatchmaker } from './services/matching.js';
import { startTelemetryBroadcast } from './services/telemetry.js';

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: env.corsOrigins, credentials: true }));
app.use(express.json({ limit: '256kb' }));
app.use(cookieParser());
app.use(pinoHttp({ logger, autoLogging: { ignore: (req) => req.url === '/api/health' } }));
app.use('/api', generalLimiter);

app.get('/api/health', async (_req, res) => {
  const [db, cache] = await Promise.allSettled([prisma.$queryRaw`SELECT 1`, redis.ping()]);
  const ok = db.status === 'fulfilled' && cache.status === 'fulfilled';
  res.status(ok ? 200 : 503).json({
    ok,
    db: db.status === 'fulfilled',
    redis: cache.status === 'fulfilled',
    uptime: process.uptime(),
  });
});

app.use('/api/auth', authRouter);
app.use('/api/me', meRouter);
app.use('/api/quiz', quizRouter);
app.use('/api/match', matchRouter);
app.use('/api/chat', chatRouter);
app.use('/api/lounge', loungeRouter);
app.use('/api/stats', statsRouter);

app.use(notFound);
app.use(errorHandler);

const server = http.createServer(app);
const io = createRealtime(server);
app.set('io', io); // routes emit through this

const stopMatchmaker = startMatchmaker(io);
const stopTelemetry = startTelemetryBroadcast(io);

server.listen(env.PORT, () => {
  logger.info(`Vibe Match API listening on :${env.PORT} (${env.NODE_ENV})`);
});

async function shutdown(signal) {
  logger.info({ signal }, 'shutting down');
  stopMatchmaker();
  stopTelemetry();
  io.close();
  server.close();
  await Promise.allSettled([prisma.$disconnect(), redis.quit()]);
  process.exit(0);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
