import { prisma } from '../lib/prisma.js';
import { redis, KEYS } from '../lib/redis.js';
import { env } from '../config/env.js';
import { logger } from '../lib/logger.js';
import { bumpDailyStat } from './telemetry.js';

const AXES = [
  ['valence', 0.9],
  ['energy', 1.0],
  ['acousticness', 1.2],
  ['danceability', 0.7],
  ['instrumentalness', 0.5],
  ['tempoNorm', 0.6],
  ['romanticDepth', 1.6],
  ['playfulness', 0.8],
  ['vulnerability', 1.4],
];

/**
 * Affinity = weighted taste closeness (70%) + shared artist/track overlap (30%),
 * expressed 0..100 — the number the chat header shows as "% Romantic Affinity".
 */
export function affinityBetween(a, b, overlap = { artists: [], tracks: [] }) {
  let num = 0;
  let den = 0;
  const breakdown = {};
  for (const [axis, w] of AXES) {
    const d = Math.abs((a[axis] ?? 0.5) - (b[axis] ?? 0.5));
    const closeness = 1 - d;
    breakdown[axis] = Math.round(closeness * 100);
    num += closeness * w;
    den += w;
  }
  const taste = num / den;

  const overlapScore = Math.min(1, (overlap.artists.length * 0.12) + (overlap.tracks.length * 0.08));
  const score = taste * 0.7 + overlapScore * 0.3;

  return {
    affinity: Math.round(score * 1000) / 10, // one decimal, e.g. 98.4
    breakdown: {
      axes: breakdown,
      sharedArtists: overlap.artists.slice(0, 8),
      sharedTracks: overlap.tracks.slice(0, 8),
      tasteComponent: Math.round(taste * 1000) / 10,
      overlapComponent: Math.round(overlapScore * 1000) / 10,
    },
  };
}

/** Threshold relaxes the longer someone has been waiting on the radar. */
export function thresholdFor(waitingMs) {
  const minutes = waitingMs / 60_000;
  const relaxed = env.MATCH_MIN_AFFINITY - minutes * env.MATCH_DECAY_PER_MIN;
  return Math.max(env.MATCH_FLOOR_AFFINITY, relaxed);
}

export async function enqueue(userId, gender) {
  const now = Date.now();
  await redis
    .multi()
    .zadd(KEYS.waitingPool(gender), now, userId)
    .hset(KEYS.waitingMeta(userId), { gender, joinedAt: now })
    .exec();
  await prisma.user.update({ where: { id: userId }, data: { state: 'WAITING' } });
}

export async function dequeue(userId) {
  const meta = await redis.hgetall(KEYS.waitingMeta(userId));
  if (meta?.gender) await redis.zrem(KEYS.waitingPool(meta.gender), userId);
  await redis.del(KEYS.waitingMeta(userId));
}

export async function queuePosition(userId) {
  const meta = await redis.hgetall(KEYS.waitingMeta(userId));
  if (!meta?.gender) return null;
  const rank = await redis.zrank(KEYS.waitingPool(meta.gender), userId);
  const [sameSide, otherSide] = await Promise.all([
    redis.zcard(KEYS.waitingPool(meta.gender)),
    redis.zcard(KEYS.waitingPool(meta.gender === 'MALE' ? 'FEMALE' : 'MALE')),
  ]);
  return {
    position: (rank ?? 0) + 1,
    waitingSameSide: sameSide,
    waitingOtherSide: otherSide,
    waitingMs: Date.now() - Number(meta.joinedAt || Date.now()),
  };
}

/** Loads every candidate's top items in one query, keyed for O(1) overlap checks. */
async function loadTopItems(userIds) {
  const rows = await prisma.topItem.findMany({
    where: { userId: { in: userIds } },
    select: { userId: true, kind: true, spotifyId: true, name: true },
  });
  const byUser = new Map(userIds.map((id) => [id, new Map()]));
  for (const r of rows) byUser.get(r.userId)?.set(`${r.kind}:${r.spotifyId}`, r.name);
  return byUser;
}

function overlapFrom(aMap, bMap) {
  const artists = [];
  const tracks = [];
  if (!aMap || !bMap) return { artists, tracks };
  const [small, large] = aMap.size <= bMap.size ? [aMap, bMap] : [bMap, aMap];
  for (const [key, name] of small) {
    if (!large.has(key)) continue;
    (key.startsWith('artist:') ? artists : tracks).push(name);
  }
  return { artists, tracks };
}

/**
 * One matchmaking pass. Pairs strictly MALE <-> FEMALE (the design guarantees
 * boy-girl pairing), oldest waiter first, best available partner above threshold.
 * Returns the rooms created this tick.
 */
export async function runMatchTick() {
  const [males, females] = await Promise.all([
    redis.zrange(KEYS.waitingPool('MALE'), 0, 199, 'WITHSCORES'),
    redis.zrange(KEYS.waitingPool('FEMALE'), 0, 199, 'WITHSCORES'),
  ]);
  const toPairs = (flat) => {
    const out = [];
    for (let i = 0; i < flat.length; i += 2) out.push({ userId: flat[i], joinedAt: Number(flat[i + 1]) });
    return out;
  };
  const m = toPairs(males);
  const f = toPairs(females);
  if (!m.length || !f.length) return [];

  const ids = [...m, ...f].map((x) => x.userId);
  const [profiles, topItems] = await Promise.all([
    prisma.vibeProfile.findMany({ where: { userId: { in: ids } } }),
    loadTopItems(ids),
  ]);
  const byUser = new Map(profiles.map((p) => [p.userId, p]));

  const used = new Set();
  const created = [];

  const queue = [...m, ...f].sort((a, b) => a.joinedAt - b.joinedAt);

  for (const seed of queue) {
    if (used.has(seed.userId)) continue;
    const seedProfile = byUser.get(seed.userId);
    if (!seedProfile) continue;

    const isMale = m.some((x) => x.userId === seed.userId);
    const pool = (isMale ? f : m).filter((x) => !used.has(x.userId));
    if (!pool.length) continue;

    let best = null;
    for (const cand of pool) {
      const p = byUser.get(cand.userId);
      if (!p) continue;
      const overlap = overlapFrom(topItems.get(seed.userId), topItems.get(cand.userId));
      const { affinity, breakdown } = affinityBetween(seedProfile, p, overlap);
      if (!best || affinity > best.affinity) best = { cand, affinity, breakdown };
    }
    if (!best) continue;

    const waited = Math.max(Date.now() - seed.joinedAt, Date.now() - best.cand.joinedAt);
    if (best.affinity < thresholdFor(waited)) continue;

    const room = await createRoom(seed.userId, best.cand.userId, best.affinity, best.breakdown);
    if (!room) continue;

    used.add(seed.userId);
    used.add(best.cand.userId);
    created.push(room);
  }

  return created;
}

async function createRoom(aId, bId, affinity, breakdown) {
  // Lock both users so two ticks (or two instances) cannot double-match them.
  const locks = await redis
    .multi()
    .set(KEYS.matchLock(aId), '1', 'NX', 'EX', 20)
    .set(KEYS.matchLock(bId), '1', 'NX', 'EX', 20)
    .exec();
  const gotBoth = locks.every(([, res]) => res === 'OK');
  if (!gotBoth) {
    await redis.del(KEYS.matchLock(aId), KEYS.matchLock(bId));
    return null;
  }

  try {
    const room = await prisma.$transaction(async (tx) => {
      const fresh = await tx.user.findMany({
        where: { id: { in: [aId, bId] } },
        select: { id: true, state: true, handle: true },
      });
      if (fresh.length !== 2 || fresh.some((u) => u.state !== 'WAITING')) return null;

      const r = await tx.room.create({
        data: { userAId: aId, userBId: bId, affinity, breakdown },
      });
      await tx.user.updateMany({ where: { id: { in: [aId, bId] } }, data: { state: 'MATCHED' } });
      await tx.message.create({
        data: {
          roomId: r.id,
          kind: 'ICEBREAKER',
          body: icebreakerFor(breakdown),
          meta: { generated: true },
        },
      });
      return r;
    });

    if (room) {
      await Promise.all([dequeue(aId), dequeue(bId)]);
      await bumpDailyStat('matchesMade', 1);
      logger.info({ roomId: room.id, affinity }, 'match created');
    }
    return room;
  } finally {
    await redis.del(KEYS.matchLock(aId), KEYS.matchLock(bId));
  }
}

const SPARKS = [
  'You both keep the same songs for the same late hours. What is the one that always finds you first?',
  'Two people, one shared silence. Tell each other the song you would never skip.',
  'Your frequencies overlap where it gets quiet. What were you listening to tonight?',
  'You both listen like someone is missing. Who taught you that song?',
];

function icebreakerFor(breakdown) {
  const shared = breakdown?.sharedArtists?.[0];
  if (shared) return `You both carry ${shared} around at night. Start there — what did that music get you through?`;
  return SPARKS[Math.floor(Math.random() * SPARKS.length)];
}

export function startMatchmaker(io) {
  const tick = async () => {
    try {
      const rooms = await runMatchTick();
      for (const room of rooms) {
        const full = await prisma.room.findUnique({
          where: { id: room.id },
          include: {
            userA: { select: { id: true, handle: true, gender: true } },
            userB: { select: { id: true, handle: true, gender: true } },
          },
        });
        const payload = (self, other) => ({
          roomId: full.id,
          affinity: full.affinity,
          partner: { handle: other.handle, gender: other.gender },
          breakdown: full.breakdown,
        });
        io.to(`user:${full.userAId}`).emit('match:found', payload(full.userA, full.userB));
        io.to(`user:${full.userBId}`).emit('match:found', payload(full.userB, full.userA));
      }
    } catch (err) {
      logger.error({ err }, 'match tick failed');
    }
  };
  const handle = setInterval(tick, env.MATCH_TICK_MS);
  tick();
  return () => clearInterval(handle);
}
