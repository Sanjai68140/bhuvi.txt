import { prisma } from '../lib/prisma.js';
import { enqueue, dequeue, queuePosition } from '../services/matching.js';
import { liveStats } from '../services/telemetry.js';

export function registerMatch(io, socket) {
  const user = socket.data.user;

  socket.on('match:join', async (_payload, ack) => {
    try {
      const fresh = await prisma.user.findUnique({
        where: { id: user.id },
        select: { gender: true, state: true },
      });
      if (!fresh.gender) return ack?.({ error: 'gender_required' });
      if (fresh.state === 'MATCHED') return ack?.({ error: 'already_matched' });
      await enqueue(user.id, fresh.gender);
      ack?.({ state: 'WAITING', queue: await queuePosition(user.id) });
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('match:leave', async (_p, ack) => {
    await dequeue(user.id);
    await prisma.user.updateMany({ where: { id: user.id, state: 'WAITING' }, data: { state: 'IDLE' } });
    ack?.({ state: 'IDLE' });
  });

  // Radar heartbeat — drives the sweeping beam and the telemetry counters.
  socket.on('match:ping', async (_p, ack) => {
    ack?.({ queue: await queuePosition(user.id), stats: await liveStats() });
  });
}
