import { Router } from 'express';
import { prisma } from '../lib/prisma.js';
import { requireAuth, requireReady } from '../middleware/auth.js';
import { ah } from '../middleware/error.js';
import { enqueue, dequeue, queuePosition } from '../services/matching.js';
import { liveStats } from '../services/telemetry.js';

export const matchRouter = Router();
matchRouter.use(requireAuth, requireReady);

/** STATE A — user steps onto the Romantic Waiting Sphere. */
matchRouter.post('/queue', ah(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.id }, select: { gender: true, state: true } });
  if (!user.gender) return res.status(409).json({ error: 'gender_required' });
  if (user.state === 'MATCHED') return res.status(409).json({ error: 'already_matched' });

  await enqueue(req.user.id, user.gender);
  res.json({ state: 'WAITING', queue: await queuePosition(req.user.id), stats: await liveStats() });
}));

matchRouter.delete('/queue', ah(async (req, res) => {
  await dequeue(req.user.id);
  await prisma.user.updateMany({
    where: { id: req.user.id, state: 'WAITING' },
    data: { state: 'IDLE' },
  });
  res.json({ state: 'IDLE' });
}));

/** Radar telemetry: position, both-side pool sizes, live counters. */
matchRouter.get('/status', ah(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.id }, select: { state: true } });
  const activeRoom = await prisma.room.findFirst({
    where: { state: 'ACTIVE', OR: [{ userAId: req.user.id }, { userBId: req.user.id }] },
    select: { id: true, affinity: true },
  });
  res.json({
    state: user.state,
    roomId: activeRoom?.id ?? null,
    affinity: activeRoom?.affinity ?? null,
    queue: user.state === 'WAITING' ? await queuePosition(req.user.id) : null,
    stats: await liveStats(),
  });
}));
