import { z } from 'zod';
import * as lounge from '../services/lounge.js';

const msgSchema = z.object({ body: z.string().trim().min(1).max(500) });

export function registerLounge(io, socket) {
  const user = socket.data.user;

  socket.on('lounge:join', async (_p, ack) => {
    socket.join('lounge');
    ack?.({
      messages: await lounge.recent(60),
      nowPlaying: await lounge.getNowPlaying(),
      pulse: await lounge.roomPulse(),
    });
  });

  socket.on('lounge:send', async (payload, ack) => {
    try {
      const { body } = msgSchema.parse(payload);
      const msg = await lounge.postMessage({ userId: user.id, handle: user.handle, body });
      const shaped = lounge.shape(msg);
      io.to('lounge').emit('lounge:message', shaped);
      ack?.(shaped);
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('lounge:react', async ({ messageId, emoji }, ack) => {
    try {
      const shaped = await lounge.toggleReaction(messageId, user.id, String(emoji).slice(0, 8));
      io.to('lounge').emit('lounge:reaction', shaped);
      ack?.(shaped);
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('lounge:leave', () => socket.leave('lounge'));
}

/** Posts the celebratory "just got matched" card the design shows inline in the lounge. */
export async function celebrateMatch(io, { userId, handle, partnerTaste }) {
  const msg = await lounge.postMessage({
    userId,
    handle,
    kind: 'MATCH_CELEBRATION',
    body: `Just got matched — leaving for our private chat. Good luck everyone, your person is out there.`,
    meta: { partnerTaste },
  });
  io.to('lounge').emit('lounge:message', lounge.shape(msg));
}
