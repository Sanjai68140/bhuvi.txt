/** Seeds synthetic listeners so the radar, lounge and landing counters have life locally. */
import { prisma } from '../lib/prisma.js';
import { generateHandle } from '../services/handles.js';

const rand = (a, b) => a + Math.random() * (b - a);
const pct = () => Math.round(rand(35, 95));

const LOUNGE_LINES = [
  'Anyone else drinking hot tea and listening to Cigarettes After Sex right now?',
  'Literally doing that right now haha. Nothing beats rain outside with headphones.',
  'That gives me so much hope! Still waiting for my girl to sync.',
  'Three weeks of Phoebe Bridgers on repeat and I regret nothing.',
];

async function main() {
  const users = [];
  for (let i = 0; i < 24; i++) {
    const gender = i % 2 === 0 ? 'MALE' : 'FEMALE';
    const user = await prisma.user.create({
      data: {
        spotifyId: `seed_${i}_${Date.now()}`,
        handle: await generateHandle(),
        gender,
        state: 'IDLE',
        vibe: {
          create: {
            valence: rand(0.15, 0.7),
            energy: rand(0.1, 0.6),
            acousticness: rand(0.4, 0.95),
            danceability: rand(0.2, 0.7),
            instrumentalness: rand(0, 0.5),
            tempoNorm: rand(0.2, 0.6),
            romanticDepth: rand(0.5, 0.98),
            playfulness: rand(0.2, 0.8),
            vulnerability: rand(0.4, 0.95),
            nocturnalTenderness: pct(),
            acousticMelancholy: pct(),
            emotionalOpenness: pct(),
            tasteChips: ['bedroom pop', 'slowcore', 'indie folk'].slice(0, 2 + (i % 2)),
          },
        },
      },
    });
    users.push(user);
  }

  for (let i = 0; i < LOUNGE_LINES.length; i++) {
    const u = users[i % users.length];
    await prisma.loungeMessage.create({
      data: { userId: u.id, handle: u.handle, body: LOUNGE_LINES[i] },
    });
  }

  console.log(`seeded ${users.length} listeners and ${LOUNGE_LINES.length} lounge messages`);
}

main().finally(() => prisma.$disconnect());
