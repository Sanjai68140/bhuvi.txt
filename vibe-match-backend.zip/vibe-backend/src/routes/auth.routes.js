import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { env } from '../config/env.js';
import { prisma } from '../lib/prisma.js';
import { redis } from '../lib/redis.js';
import { authorizeUrl, exchangeCode, spotify } from '../services/spotify.js';
import { ingestSpotifyTaste } from '../services/vibe.js';
import { generateHandle } from '../services/handles.js';
import { signToken, requireAuth } from '../middleware/auth.js';
import { ah } from '../middleware/error.js';
import { authLimiter } from '../middleware/rateLimit.js';

export const authRouter = Router();

/** PHASE 1 — "Dynamic Soulmate Spotify Button" sends the user here. */
authRouter.get('/spotify', authLimiter, ah(async (req, res) => {
  const state = crypto.randomBytes(16).toString('hex');
  const returnTo = typeof req.query.returnTo === 'string' ? req.query.returnTo : '/onboarding';
  await redis.set(`oauth:state:${state}`, returnTo, 'EX', 600);
  res.redirect(authorizeUrl(state));
}));

authRouter.get('/spotify/callback', authLimiter, ah(async (req, res) => {
  const { code, state, error } = req.query;
  if (error) return res.redirect(`${env.WEB_URL}/auth/error?reason=${encodeURIComponent(String(error))}`);

  const returnTo = state ? await redis.getdel(`oauth:state:${state}`) : null;
  if (!returnTo) return res.redirect(`${env.WEB_URL}/auth/error?reason=bad_state`);

  const token = await exchangeCode(String(code));
  const me = await spotify.me(token.access_token);

  const existing = await prisma.user.findUnique({ where: { spotifyId: me.id } });
  const user = await prisma.user.upsert({
    where: { spotifyId: me.id },
    create: {
      spotifyId: me.id,
      handle: await generateHandle(),
      displayName: me.display_name ?? null,
      email: me.email ?? null,
      avatarUrl: me.images?.[0]?.url ?? null,
      country: me.country ?? null,
      accessToken: token.access_token,
      refreshToken: token.refresh_token,
      tokenExpires: new Date(Date.now() + token.expires_in * 1000),
    },
    update: {
      accessToken: token.access_token,
      refreshToken: token.refresh_token ?? existing?.refreshToken,
      tokenExpires: new Date(Date.now() + token.expires_in * 1000),
      lastSeenAt: new Date(),
    },
  });

  // Fire-and-forget taste ingestion so the callback stays fast.
  ingestSpotifyTaste(user.id).catch(() => {});

  const jwtToken = signToken(user.id);
  res.cookie?.('vm_session', jwtToken, {
    httpOnly: true,
    secure: env.isProd,
    sameSite: env.isProd ? 'none' : 'lax',
    maxAge: 30 * 24 * 3600 * 1000,
  });
  const next = user.state === 'ONBOARDING' ? '/onboarding' : returnTo;
  res.redirect(`${env.WEB_URL}${next}#token=${jwtToken}`);
}));

/** Completes onboarding: gender is required because pairing is guaranteed boy-girl. */
const genderSchema = z.object({ gender: z.enum(['MALE', 'FEMALE']), timezone: z.string().optional() });

authRouter.post('/gender', requireAuth, ah(async (req, res) => {
  const { gender, timezone } = genderSchema.parse(req.body);
  const hasQuiz = await prisma.quizAnswer.count({ where: { userId: req.user.id } });
  const user = await prisma.user.update({
    where: { id: req.user.id },
    data: {
      gender,
      timezone: timezone ?? undefined,
      state: hasQuiz > 0 ? 'IDLE' : 'ONBOARDING',
    },
    select: { id: true, handle: true, gender: true, state: true },
  });
  res.json(user);
}));

authRouter.post('/logout', requireAuth, ah(async (_req, res) => {
  res.clearCookie?.('vm_session');
  res.json({ ok: true });
}));
