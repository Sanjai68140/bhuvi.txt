import { Router } from 'express';
import { prisma } from '../lib/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { ah } from '../middleware/error.js';
import { ingestSpotifyTaste, publicVibe } from '../services/vibe.js';
import { queuePosition } from '../services/matching.js';

export const meRouter = Router();
meRouter.use(requireAuth);

meRouter.get('/', ah(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    include: { vibe: true },
  });
  const activeRoom = await prisma.room.findFirst({
    where: { state: 'ACTIVE', OR: [{ userAId: user.id }, { userBId: user.id }] },
    select: { id: true, affinity: true },
  });
  res.json({
    id: user.id,
    handle: user.handle,
    gender: user.gender,
    state: user.state,
    spotifyLinked: Boolean(user.spotifyId),
    vibe: publicVibe(user.vibe),
    activeRoomId: activeRoom?.id ?? null,
    queue: user.state === 'WAITING' ? await queuePosition(user.id) : null,
  });
}));

meRouter.get('/top-tracks', ah(async (req, res) => {
  const items = await prisma.topItem.findMany({
    where: { userId: req.user.id, kind: 'track' },
    orderBy: { rank: 'asc' },
    take: 50,
  });
  res.json({ items });
}));

meRouter.post('/refresh-taste', ah(async (req, res) => {
  const profile = await ingestSpotifyTaste(req.user.id);
  res.json({ vibe: publicVibe(profile) });
}));
