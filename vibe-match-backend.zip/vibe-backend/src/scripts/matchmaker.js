/**
 * Optional standalone matchmaker. Use this when you scale the API to more than
 * one instance: run the web dyno with MATCH_TICK_MS=0 handling and this process
 * as the single pairing worker, publishing results over Redis.
 */
import { runMatchTick } from '../services/matching.js';
import { logger } from '../lib/logger.js';
import { env } from '../config/env.js';
import { redis } from '../lib/redis.js';

async function loop() {
  try {
    const rooms = await runMatchTick();
    for (const room of rooms) {
      await redis.publish('match:created', JSON.stringify({ roomId: room.id }));
    }
  } catch (err) {
    logger.error({ err }, 'standalone match tick failed');
  } finally {
    setTimeout(loop, env.MATCH_TICK_MS);
  }
}
logger.info('standalone matchmaker started');
loop();
