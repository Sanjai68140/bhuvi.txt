import { Router } from 'express';
import { z } from 'zod';
import { requireAuth, requireReady } from '../middleware/auth.js';
import { ah } from '../middleware/error.js';
import { writeLimiter } from '../middleware/rateLimit.js';
import * as lounge from '../services/lounge.js';
import { spotify } from '../services/spotify.js';

export const loungeRouter = Router();

/** Public read so the Starlit Commons preview renders before sign-in. */
loungeRouter.get('/messages', ah(async (req, res) => {
  res.json({ messages: await lounge.recent(Number(req.query.limit) || 60, req.query.before) });
}));

loungeRouter.get('/pulse', ah(async (_req, res) => {
  res.json({ pulse: await lounge.roomPulse(), nowPlaying: await lounge.getNowPlaying() });
}));

loungeRouter.use(requireAuth, requireReady);

const postSchema = z.object({ body: z.string().trim().min(1).max(500) });

loungeRouter.post('/messages', writeLimiter, ah(async (req, res) => {
  const { body } = postSchema.parse(req.body);
  const msg = await lounge.postMessage({ userId: req.user.id, handle: req.user.handle, body });
  const shaped = lounge.shape(msg);
  req.app.get('io')?.to('lounge').emit('lounge:message', shaped);
  res.status(201).json(shaped);
}));

loungeRouter.post('/messages/:id/reactions', writeLimiter, ah(async (req, res) => {
  const emoji = z.string().min(1).max(8).parse(req.body?.emoji);
  const shaped = await lounge.toggleReaction(req.params.id, req.user.id, emoji);
  req.app.get('io')?.to('lounge').emit('lounge:reaction', shaped);
  res.json(shaped);
}));

/** Sets the track everyone in the Commons listens to together. */
loungeRouter.post('/now-playing', writeLimiter, ah(async (req, res) => {
  const spotifyId = z.string().min(5).parse(req.body?.spotifyId);
  const track = await spotify.track(req.user.id, spotifyId);
  const np = await lounge.setNowPlaying({
    spotifyId,
    title: track.name,
    artist: track.artists?.map((a) => a.name).join(', '),
    album: track.album?.name,
    albumArtUrl: track.album?.images?.[0]?.url ?? null,
    durationMs: track.duration_ms,
    setBy: req.user.handle,
  });
  req.app.get('io')?.to('lounge').emit('lounge:nowplaying', np);
  res.json(np);
}));
