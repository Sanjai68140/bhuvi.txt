import { Server } from 'socket.io';
import { env } from '../config/env.js';
import { prisma } from '../lib/prisma.js';
import { verifyToken } from '../middleware/auth.js';
import { logger } from '../lib/logger.js';
import { heartbeat, goOffline, liveStats } from '../services/telemetry.js';
import { registerChat } from './chat.gateway.js';
import { registerLounge } from './lounge.gateway.js';
import { registerMatch } from './match.gateway.js';

export function createRealtime(httpServer) {
  const io = new Server(httpServer, {
    cors: { origin: env.corsOrigins, credentials: true },
    pingInterval: 20_000,
    pingTimeout: 25_000,
  });

  io.use(async (socket, next) => {
    try {
      const token =
        socket.handshake.auth?.token ||
        (socket.handshake.headers.authorization || '').replace('Bearer ', '');
      if (!token) return next(new Error('unauthenticated'));
      const { sub } = verifyToken(token);
      const user = await prisma.user.findUnique({
        where: { id: sub },
        select: { id: true, handle: true, gender: true, state: true },
      });
      if (!user) return next(new Error('unauthenticated'));
      socket.data.user = user;
      next();
    } catch {
      next(new Error('unauthenticated'));
    }
  });

  io.on('connection', async (socket) => {
    const user = socket.data.user;
    socket.join(`user:${user.id}`);
    await heartbeat(user.id, user.gender);
    socket.emit('stats:live', await liveStats());

    const beat = setInterval(() => heartbeat(user.id, user.gender).catch(() => {}), 20_000);

    registerMatch(io, socket);
    registerChat(io, socket);
    registerLounge(io, socket);

    socket.on('disconnect', async () => {
      clearInterval(beat);
      const remaining = await io.in(`user:${user.id}`).fetchSockets();
      if (remaining.length === 0) await goOffline(user.id, user.gender).catch(() => {});
      logger.debug({ userId: user.id }, 'socket disconnected');
    });
  });

  return io;
}
