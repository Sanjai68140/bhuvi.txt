import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { ah } from '../middleware/error.js';
import { QUIZ, recomputeProfile, publicVibe } from '../services/vibe.js';

export const quizRouter = Router();

/** Public — the Phase 1 "Romantic Vibe Quiz Teaser" renders from this. */
quizRouter.get('/', (_req, res) => {
  res.json({
    version: QUIZ.version,
    questions: QUIZ.questions.map((q) => ({
      id: q.id,
      prompt: q.prompt,
      options: q.options.map((o) => ({ id: o.id, label: o.label })),
    })),
  });
});

const answerSchema = z.object({
  answers: z.array(z.object({ questionId: z.string(), optionId: z.string() })).min(1),
});

quizRouter.post('/answers', requireAuth, ah(async (req, res) => {
  const { answers } = answerSchema.parse(req.body);

  for (const a of answers) {
    const q = QUIZ.questions.find((x) => x.id === a.questionId);
    if (!q || !q.options.some((o) => o.id === a.optionId)) {
      return res.status(422).json({ error: 'unknown_answer', questionId: a.questionId });
    }
  }

  await prisma.$transaction(
    answers.map((a) =>
      prisma.quizAnswer.upsert({
        where: { userId_questionId: { userId: req.user.id, questionId: a.questionId } },
        create: { userId: req.user.id, questionId: a.questionId, optionId: a.optionId },
        update: { optionId: a.optionId },
      }),
    ),
  );

  const profile = await recomputeProfile(req.user.id);

  const answered = await prisma.quizAnswer.count({ where: { userId: req.user.id } });
  const complete = answered >= QUIZ.questions.length;
  const user = await prisma.user.findUnique({ where: { id: req.user.id }, select: { gender: true, state: true } });
  if (complete && user.gender && user.state === 'ONBOARDING') {
    await prisma.user.update({ where: { id: req.user.id }, data: { state: 'IDLE' } });
  }

  res.json({ answered, total: QUIZ.questions.length, complete, vibe: publicVibe(profile) });
}));
