import { logger } from '../lib/logger.js';
import { ZodError } from 'zod';

export function notFound(_req, res) {
  res.status(404).json({ error: 'not_found' });
}

export function errorHandler(err, _req, res, _next) {
  if (err instanceof ZodError) {
    return res.status(422).json({ error: 'validation_failed', details: err.flatten() });
  }
  const status = err.status || 500;
  if (status >= 500) logger.error({ err }, 'unhandled error');
  res.status(status).json({ error: err.code || err.message || 'internal_error' });
}

/** Wraps async route handlers so rejections reach errorHandler. */
export const ah = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
