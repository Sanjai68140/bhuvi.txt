import { Router } from 'express';
import { ah } from '../middleware/error.js';
import { liveStats } from '../services/telemetry.js';

export const statsRouter = Router();

/** Public — landing page "THE ROOM RIGHT NOW" bento grid polls this. */
statsRouter.get('/live', ah(async (_req, res) => {
  res.set('Cache-Control', 'public, max-age=3');
  res.json(await liveStats());
}));
