import { prisma } from '../lib/prisma.js';
import { redis, KEYS } from '../lib/redis.js';

export async function postMessage({ userId, handle, body, kind = 'TEXT', meta = null }) {
  return prisma.loungeMessage.create({
    data: { userId, handle, body, kind, meta },
    include: { reactions: true },
  });
}

export async function recent(limit = 60, before) {
  const rows = await prisma.loungeMessage.findMany({
    where: before ? { createdAt: { lt: new Date(before) } } : undefined,
    orderBy: { createdAt: 'desc' },
    take: Math.min(limit, 100),
    include: { reactions: { select: { emoji: true, userId: true } } },
  });
  return rows.reverse().map(shape);
}

export function shape(m) {
  const counts = {};
  for (const r of m.reactions || []) counts[r.emoji] = (counts[r.emoji] || 0) + 1;
  return {
    id: m.id,
    handle: m.handle,
    body: m.body,
    kind: m.kind,
    meta: m.meta,
    createdAt: m.createdAt,
    reactions: Object.entries(counts).map(([emoji, count]) => ({ emoji, count })),
  };
}

export async function toggleReaction(messageId, userId, emoji) {
  const existing = await prisma.loungeReaction.findUnique({
    where: { messageId_userId_emoji: { messageId, userId, emoji } },
  });
  if (existing) {
    await prisma.loungeReaction.delete({ where: { id: existing.id } });
  } else {
    await prisma.loungeReaction.create({ data: { messageId, userId, emoji } });
  }
  const msg = await prisma.loungeMessage.findUnique({
    where: { id: messageId },
    include: { reactions: { select: { emoji: true, userId: true } } },
  });
  return shape(msg);
}

/** "Now Playing in Commons" — one track synced across every listener in the node. */
export async function getNowPlaying() {
  const raw = await redis.get(KEYS.loungeNowPlaying);
  if (!raw) return null;
  const np = JSON.parse(raw);
  np.positionMs = Math.max(0, Date.now() - np.startedAt);
  return np;
}

export async function setNowPlaying(track) {
  const payload = { ...track, startedAt: Date.now() };
  await redis.set(KEYS.loungeNowPlaying, JSON.stringify(payload), 'EX', 3600);
  return payload;
}

/** Collective frequency bars on the sideboard: average vibe of everyone online. */
export async function roomPulse() {
  const onlineIds = await redis.zrange(KEYS.online, 0, 499);
  if (!onlineIds.length) return { tenderness: 0, melancholy: 0, openness: 0, sampled: 0 };
  const rows = await prisma.vibeProfile.findMany({
    where: { userId: { in: onlineIds } },
    select: { nocturnalTenderness: true, acousticMelancholy: true, emotionalOpenness: true },
  });
  if (!rows.length) return { tenderness: 0, melancholy: 0, openness: 0, sampled: 0 };
  const mean = (k) => Math.round(rows.reduce((a, r) => a + r[k], 0) / rows.length);
  return {
    tenderness: mean('nocturnalTenderness'),
    melancholy: mean('acousticMelancholy'),
    openness: mean('emotionalOpenness'),
    sampled: rows.length,
  };
}
